# rpg
it's a text-based role playing game. hours of bland mediocrity! 

Featuers
 - (ha none yet)
 
Version History
 - 11/30/18
     * lots of skeleton code
     * running main does 3 lines of text
